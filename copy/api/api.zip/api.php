<?php
require 'vendor/autoload.php'; 
use \Firebase\JWT\JWT;
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$app = \Slim\Factory\AppFactory::create();

require_once 'database.php';

header('Content-Type: application/json');
define('SECRET_KEY', 'your-secret-key');  // your secret key for JWT

function verify_token($jwt) {
    try {
        JWT::decode($jwt, SECRET_KEY, array('HS256'));
        return true;
    } catch (Exception $e) {
        return false;
    }
}

$jwt_middleware = function ($request, $response, $next) {
    $jwt = $request->getHeader('Authorization');
    if ($jwt) {
        $jwt = str_replace('Bearer ', '', $jwt[0]);
        if (verify_token($jwt)) {
            $request = $request->withAttribute('jwt', $jwt);
            $response = $next($request, $response);
            return $response;
        }
    }
    return $response->withStatus(401);
};


// Define a function that will be used to encode our JWTs
function encode_jwt($token) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $base64UrlHeader = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));

    $payload = json_encode($token);
    $base64UrlPayload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));

    $signature = hash_hmac('sha256', $base64UrlHeader . "." . $base64UrlPayload, SECRET_KEY, true);
    $base64UrlSignature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    return $base64UrlHeader . "." . $base64UrlPayload . "." . $base64UrlSignature;
}

// Define a function that will be used to decode our JWTs
function decode_jwt($jwt) {
    list($header, $payload, $signature) = explode('.', $jwt);

    $base64UrlHeader = str_replace(['-', '_', ''], ['+', '/', '='], $header);
    $decodedHeader = json_decode(base64_decode($base64UrlHeader), true);

    $base64UrlPayload = str_replace(['-', '_', ''], ['+', '/', '='], $payload);
    $decodedPayload = json_decode(base64_decode($base64UrlPayload), true);

    $base64UrlSignature = str_replace(['-', '_', ''], ['+', '/', '='], $signature);
    $decodedSignature = base64_decode($base64UrlSignature);

    $validSignature = hash_hmac('sha256', $header . "." . $payload, SECRET_KEY, true);

    if ($decodedSignature != $validSignature) {
        return false;
    }

    return $decodedPayload;
}

$app->post('/login', function (Request $request, Response $response) use ($pdo) {
    $body = $request->getParsedBody();
    $username = $body['username'];
    $password = $body['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        $payload = [
            'username' => $username,
            'is_admin' => $user['is_admin'],
            'iat' => time(),
            'exp' => time() + (60*60) // 1 hour expiration
        ];
        $jwt = encode_jwt($payload);
        return $response->withJson(['jwt' => $jwt]);
    }

    return $response->withStatus(401);
});

$app->post('/register', function (Request $request, Response $response) use ($pdo) {
    $body = $request->getParsedBody();
    $username = $body['username'];
    $password = password_hash($body['password'], PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
    $result = $stmt->execute([$username, $password]);

    if ($result) {
        return $response->withStatus(200);
    }

    return $response->withStatus(500);
});

$app->get('/dashboard/{username}', function (Request $request, Response $response, array $args) use ($pdo) {
    $username = $args['username'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user) {
        return $response->withJson($user);
    }

    return $response->withStatus(404);
})->add($jwt_middleware);

$app->post('/submit_code', function (Request $request, Response $response) use ($pdo) {
    $body = $request->getParsedBody();
    $username = $body['username'];
    $code = $body['code'];

    // Check if code is valid
    $stmt = $pdo->prepare("SELECT * FROM codes WHERE code = ? AND is_active = 1");
    $stmt->execute([$code]);
    $codeData = $stmt->fetch();

    // If code is valid, update user's expiration date and code's status
    if ($codeData) {
        $stmt = $pdo->prepare("UPDATE users SET expiration_date = DATE_ADD(CURDATE(), INTERVAL ? DAY) WHERE username = ?");
        $stmt->execute([$codeData['duration'], $username]);

        $stmt = $pdo->prepare("UPDATE codes SET used_by = ?, is_active = 0, used_date = CURRENT_DATE WHERE code = ?");
        $stmt->execute([$username, $code]);

        return $response->withStatus(200);
    }

    return $response->withStatus(400);
})->add($jwt_middleware);

// Rest of your code...

// Route to get user account status
$app->get('/user/{username}/status', function (Request $request, Response $response, $args) use ($pdo) {
    $username = $args['username'];
    $stmt = $pdo->prepare("SELECT is_active FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user) {
        $status = $user['is_active'] ? 'active' : 'inactive';
        $response->getBody()->write(json_encode(['status' => $status]));
    } else {
        $response->getBody()->write(json_encode(['error' => 'User not found']));
        return $response->withStatus(404);
    }

    return $response->withHeader('Content-Type', 'application/json');
});

// Route to get user expiration date
$app->get('/user/{username}/expiration', function (Request $request, Response $response, $args) use ($pdo) {
    $username = $args['username'];
    $stmt = $pdo->prepare("SELECT expiration_date FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch();

    if ($user) {
        $expiration_date = $user['expiration_date'];
        $response->getBody()->write(json_encode(['expiration_date' => $expiration_date]));
    } else {
        $response->getBody()->write(json_encode(['error' => 'User not found']));
        return $response->withStatus(404);
    }

    return $response->withHeader('Content-Type', 'application/json');
});

// Rest of your code...


$app->run();
